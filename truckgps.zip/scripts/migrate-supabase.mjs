/**
 * Ejecuta migraciones SQL contra Supabase Postgres.
 *
 * Uso (PowerShell):
 *   $env:SUPABASE_DB_PASSWORD="tu_password_de_database"
 *   node scripts/migrate-supabase.mjs
 *
 * La contraseña está en: Supabase Dashboard → Project Settings → Database → Database password
 * (NO es la API secret key)
 */
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';

const PROJECT_REF = 'oihfscgkigahmanxakoz';
const password = process.env.SUPABASE_DB_PASSWORD;

if (!password) {
  console.error('Falta SUPABASE_DB_PASSWORD (contraseña de Database en Supabase Settings).');
  process.exit(1);
}

const connectionString =
  process.env.SUPABASE_DB_URL ??
  `postgresql://postgres:${encodeURIComponent(password)}@db.${PROJECT_REF}.supabase.co:5432/postgres`;

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const files = [
  join(root, 'supabase/migrations/001_initial_schema.sql'),
  join(root, 'supabase/seed.sql')
];

const client = new pg.Client({
  connectionString,
  ssl: { rejectUnauthorized: false }
});

try {
  await client.connect();
  console.log('Conectado a Supabase Postgres.');

  for (const file of files) {
    const sql = readFileSync(file, 'utf8');
    console.log(`Ejecutando ${file}...`);
    await client.query(sql);
    console.log(`OK: ${file}`);
  }

  const { rows } = await client.query(
    'select count(*)::int as n from public.vehicles'
  );
  console.log(`Vehículos en BD: ${rows[0]?.n ?? 0}`);
  console.log('Migración completada.');
} catch (err) {
  console.error('Error en migración:', err.message);
  if (String(err.message).includes('Tenant or user not found')) {
    console.error('Prueba con región distinta. En Supabase → Database → Connection string copia el URI del pooler Session mode.');
  }
  process.exit(1);
} finally {
  await client.end();
}
