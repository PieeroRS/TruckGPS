-- TruckGPS — datos iniciales (ejecutar DESPUÉS de 001_initial_schema.sql)
-- Crear antes un usuario en Authentication → Users (ej. operaciones@truckgps.pe)

-- ---------------------------------------------------------------------------
-- Vehículos (12 unidades del prototipo)
-- ---------------------------------------------------------------------------
insert into public.vehicles (placa, modelo, estado, ruta, kilometraje, prox_mantenimiento, lat, lng, velocidad) values
  ('ABC-123', 'Volvo FH 540', 'ok', 'Lima → Trujillo', 142850, '2026-06-12', -12.0464, -77.0428, 78),
  ('DGR-456', 'Scania R 450', 'warn', 'Arequipa → Cusco', 98430, '2026-05-18', -16.409, -71.537, 0),
  ('PER-789', 'Mercedes Actros', 'alert', 'Lima → Huancayo', 215120, '2026-05-09', -11.9404, -76.2356, 12),
  ('TGS-901', 'Volvo FH 460', 'ok', 'Trujillo → Chiclayo', 67320, '2026-08-01', -8.115, -79.029, 92),
  ('LMA-202', 'Scania G 410', 'ok', 'Lima → Pisco', 184700, '2026-07-22', -13.7, -76.21, 85),
  ('AQP-334', 'Mercedes Axor', 'warn', 'Arequipa → Tacna', 121040, '2026-05-25', -17.0, -70.85, 45),
  ('CUS-558', 'Volvo FM 380', 'ok', 'Cusco → Puno', 88990, '2026-09-03', -14.5, -71.2, 62),
  ('PIU-101', 'Scania R 500', 'alert', 'Piura → Tumbes', 152300, '2026-05-08', -4.4, -80.2, 0),
  ('CHI-742', 'Volvo FH 540', 'ok', 'Chiclayo → Cajamarca', 73810, '2026-10-14', -6.77, -78.95, 71),
  ('ICA-960', 'Mercedes Actros', 'offline', 'Ica → Nazca', 198400, '2026-06-30', -14.83, -74.93, 0),
  ('TRJ-013', 'Volvo FM 460', 'ok', 'Trujillo → Lima', 54720, '2026-11-05', -9.5, -77.5, 88),
  ('JUL-477', 'Scania P 410', 'warn', 'Juliaca → Cusco', 110650, '2026-05-29', -15.5, -70.13, 38);

-- ---------------------------------------------------------------------------
-- Viajes activos (dashboard)
-- ---------------------------------------------------------------------------
insert into public.trips (vehicle_id, ruta, progress_pct, status)
select id, 'Lima → Trujillo', 68, 'active'::trip_status from public.vehicles where placa = 'ABC-123'
union all
select id, 'Arequipa → Cusco', 42, 'active'::trip_status from public.vehicles where placa = 'DGR-456'
union all
select id, 'Trujillo → Chiclayo', 85, 'active'::trip_status from public.vehicles where placa = 'TGS-901'
union all
select id, 'Lima → Pisco', 94, 'active'::trip_status from public.vehicles where placa = 'LMA-202';

-- ---------------------------------------------------------------------------
-- Alertas IA
-- ---------------------------------------------------------------------------
insert into public.ai_alerts (titulo, descripcion, severidad, icon, placas_afectadas) values
  ('Retraso detectado en Carretera Central', 'Patrón de tráfico sugiere retrasos de 35-50 min en las próximas 2h. 3 unidades afectadas.', 'high'::incident_severity, 'alert-triangle', array['PER-789', 'ABC-123', 'TRJ-013']),
  ('Riesgo de mantenimiento — DGR-456', 'Modelo predictivo: 78% probabilidad de falla en transmisión en próximos 5 días.', 'medium'::incident_severity, 'wrench', array['DGR-456']),
  ('Zona de alto riesgo — Panamericana Norte', 'Aumento del 40% en incidentes de seguridad en km 980-1050 últimas 72h.', 'high'::incident_severity, 'shield-alert', array['PIU-101']),
  ('Optimización de ruta — Lima → Pisco', 'Ruta alternativa por Cañete reduce tiempo estimado en 28 min.', 'low'::incident_severity, 'route', array['LMA-202']),
  ('Fatiga de conductor detectada', 'Patrón de conducción de Hugo Mamani sugiere fatiga. Recomendar descanso.', 'medium'::incident_severity, 'moon', array['TRJ-013']);

-- ---------------------------------------------------------------------------
-- Incidencias de ejemplo (requiere vehicle_id)
-- ---------------------------------------------------------------------------
insert into public.incidents (id, vehicle_id, titulo, categoria, severidad, estado, ubicacion, lat, lng, descripcion, asignado_a, es_panico, created_at, updated_at)
select
  'INC-2026-0142',
  v.id,
  'Falla en sistema de frenos',
  'Mecánico',
  'high'::incident_severity,
  'en-atencion'::incident_status,
  'Carretera Central km 78, Chosica',
  -11.9404,
  -76.2356,
  'El sistema de frenos presenta pérdida de presión. Conductor reporta vibración al frenar a alta velocidad.',
  'Equipo Mecánico Lima Norte',
  false,
  '2026-05-06T08:42:00+00',
  '2026-05-06T11:15:00+00'
from public.vehicles v where v.placa = 'PER-789';

insert into public.incident_events (incident_id, estado, notas)
values
  ('INC-2026-0142', 'reportado'::incident_status, 'Incidencia registrada'),
  ('INC-2026-0142', 'asignado'::incident_status, 'Asignado a equipo mecánico'),
  ('INC-2026-0142', 'en-atencion'::incident_status, 'Técnico en camino');

-- Repetir patrón para más incidencias según necesidad; la app también permite crear nuevas.

-- ---------------------------------------------------------------------------
-- Storage: crear buckets en Dashboard → Storage
--   - incident-photos (public o authenticated)
--   - incident-audio (authenticated)
-- Política ejemplo (authenticated pueden subir):
-- create policy "auth upload photos" on storage.objects for insert to authenticated
--   with check (bucket_id = 'incident-photos');
