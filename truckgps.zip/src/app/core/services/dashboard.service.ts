import { Injectable, inject, signal } from '@angular/core';
import {
  SEED_ACTIVITY,
  SEED_AI_ALERTS,
  SEED_KPIS,
  SEED_ROUTES
} from '../data/seed.data';
import { ActivityItem, AiAlert, Kpi, RouteProgress } from '../models/dashboard.model';
import { AiAlertRow, mapAiAlertRow, TripRow } from '../supabase/supabase.mappers';
import { SupabaseService } from '../supabase/supabase.service';
import { FleetService } from './fleet.service';
import { IncidentService } from './incident.service';

@Injectable({ providedIn: 'root' })
export class DashboardService {
  private readonly supabase = inject(SupabaseService);
  private readonly fleet = inject(FleetService);
  private readonly incidents = inject(IncidentService);

  readonly kpis = signal<Kpi[]>(SEED_KPIS);
  readonly aiAlerts = signal<AiAlert[]>(SEED_AI_ALERTS);
  readonly activity = signal<ActivityItem[]>(SEED_ACTIVITY);
  readonly routes = signal<RouteProgress[]>(SEED_ROUTES);
  readonly loading = signal(false);

  readonly daySummary = signal({
    distancia: '3,247 km',
    entregas: '14 / 18',
    combustible: '847 L',
    resueltas: '5 / 7',
    eficiencia: '92%'
  });

  async load(): Promise<void> {
    if (!this.supabase.client) return;

    this.loading.set(true);
    try {
      await Promise.all([this.fleet.load(), this.incidents.load()]);

      const [{ data: alerts }, { data: trips }] = await Promise.all([
        this.supabase.client.from('ai_alerts').select('*').eq('activa', true).order('created_at', { ascending: false }),
        this.supabase.client.from('trips').select('ruta, progress_pct').eq('status', 'active')
      ]);

      if (alerts?.length) {
        this.aiAlerts.set((alerts as AiAlertRow[]).map(mapAiAlertRow));
      }

      if (trips?.length) {
        this.routes.set(
          (trips as TripRow[]).map((t) => ({
            ruta: t.ruta,
            pct: t.progress_pct,
            color: t.progress_pct >= 60 ? 'emerald' : 'amber'
          })) as RouteProgress[]
        );
      }

      this.recomputeKpis();
    } finally {
      this.loading.set(false);
    }
  }

  private recomputeKpis(): void {
    const fleetTotal = this.fleet.count();
    const active = this.fleet.vehicles().filter((v) => v.estado === 'ok').length;
    const incToday = this.incidents.incidents().length;
    const pendingAi = this.aiAlerts().length;

    this.kpis.set([
      {
        label: 'Vehículos activos',
        value: `${active} / ${fleetTotal}`,
        trend: '+0',
        icon: 'truck',
        color: 'blue'
      },
      {
        label: 'Incidencias registradas',
        value: String(incToday),
        trend: '—',
        icon: 'alert-triangle',
        color: 'red'
      },
      {
        label: 'Tiempo promedio respuesta',
        value: '18 min',
        trend: '-3 min',
        icon: 'clock',
        color: 'green'
      },
      {
        label: 'Alertas IA pendientes',
        value: String(pendingAi),
        trend: '+0',
        icon: 'sparkles',
        color: 'violet'
      }
    ]);
  }
}
