import { AiAlert, ActivityItem, Kpi, RouteProgress } from '../models/dashboard.model';
import { Incident } from '../models/incident.model';
import { ChartBars, ChartDonut, ChartTrend, HeatmapPoint } from '../models/reports.model';
import { Vehicle } from '../models/vehicle.model';

export const SEED_VEHICLES: Vehicle[] = [
  { placa: 'ABC-123', conductor: 'Carlos Mendoza', modelo: 'Volvo FH 540', estado: 'ok', ruta: 'Lima → Trujillo', lat: -12.0464, lng: -77.0428, velocidad: 78, km: 142850, proxMant: '2026-06-12' },
  { placa: 'DGR-456', conductor: 'María Quispe', modelo: 'Scania R 450', estado: 'warn', ruta: 'Arequipa → Cusco', lat: -16.409, lng: -71.537, velocidad: 0, km: 98430, proxMant: '2026-05-18' },
  { placa: 'PER-789', conductor: 'Luis Vargas', modelo: 'Mercedes Actros', estado: 'alert', ruta: 'Lima → Huancayo', lat: -11.9404, lng: -76.2356, velocidad: 12, km: 215120, proxMant: '2026-05-09' },
  { placa: 'TGS-901', conductor: 'Ana Flores', modelo: 'Volvo FH 460', estado: 'ok', ruta: 'Trujillo → Chiclayo', lat: -8.115, lng: -79.029, velocidad: 92, km: 67320, proxMant: '2026-08-01' },
  { placa: 'LMA-202', conductor: 'Jorge Salazar', modelo: 'Scania G 410', estado: 'ok', ruta: 'Lima → Pisco', lat: -13.7, lng: -76.21, velocidad: 85, km: 184700, proxMant: '2026-07-22' },
  { placa: 'AQP-334', conductor: 'Rosa Huamán', modelo: 'Mercedes Axor', estado: 'warn', ruta: 'Arequipa → Tacna', lat: -17.0, lng: -70.85, velocidad: 45, km: 121040, proxMant: '2026-05-25' },
  { placa: 'CUS-558', conductor: 'Pedro Ñaupa', modelo: 'Volvo FM 380', estado: 'ok', ruta: 'Cusco → Puno', lat: -14.5, lng: -71.2, velocidad: 62, km: 88990, proxMant: '2026-09-03' },
  { placa: 'PIU-101', conductor: 'Sandra Rojas', modelo: 'Scania R 500', estado: 'alert', ruta: 'Piura → Tumbes', lat: -4.4, lng: -80.2, velocidad: 0, km: 152300, proxMant: '2026-05-08' },
  { placa: 'CHI-742', conductor: 'Manuel Torres', modelo: 'Volvo FH 540', estado: 'ok', ruta: 'Chiclayo → Cajamarca', lat: -6.77, lng: -78.95, velocidad: 71, km: 73810, proxMant: '2026-10-14' },
  { placa: 'ICA-960', conductor: 'Diana Castillo', modelo: 'Mercedes Actros', estado: 'offline', ruta: 'Ica → Nazca', lat: -14.83, lng: -74.93, velocidad: 0, km: 198400, proxMant: '2026-06-30' },
  { placa: 'TRJ-013', conductor: 'Hugo Mamani', modelo: 'Volvo FM 460', estado: 'ok', ruta: 'Trujillo → Lima', lat: -9.5, lng: -77.5, velocidad: 88, km: 54720, proxMant: '2026-11-05' },
  { placa: 'JUL-477', conductor: 'Elena Choque', modelo: 'Scania P 410', estado: 'warn', ruta: 'Juliaca → Cusco', lat: -15.5, lng: -70.13, velocidad: 38, km: 110650, proxMant: '2026-05-29' }
];

export const SEED_INCIDENTS: Incident[] = [
  { id: 'INC-2026-0142', titulo: 'Falla en sistema de frenos', placa: 'PER-789', conductor: 'Luis Vargas', categoria: 'Mecánico', severidad: 'high', estado: 'en-atencion', ubicacion: 'Carretera Central km 78, Chosica', lat: -11.9404, lng: -76.2356, descripcion: 'El sistema de frenos presenta pérdida de presión. Conductor reporta vibración al frenar a alta velocidad.', creado: '2026-05-06T08:42:00', actualizado: '2026-05-06T11:15:00', asignadoA: 'Equipo Mecánico Lima Norte', foto: true, audio: true },
  { id: 'INC-2026-0141', titulo: 'Vehículo detenido sin reportar', placa: 'DGR-456', conductor: 'María Quispe', categoria: 'Operativo', severidad: 'medium', estado: 'asignado', ubicacion: 'Salida sur de Arequipa', lat: -16.409, lng: -71.537, descripcion: 'GPS muestra detención de 45 minutos sin reporte del conductor.', creado: '2026-05-06T10:05:00', actualizado: '2026-05-06T10:30:00', asignadoA: 'Coordinador Sur', foto: false, audio: false },
  { id: 'INC-2026-0140', titulo: 'Intento de robo a unidad', placa: 'PIU-101', conductor: 'Sandra Rojas', categoria: 'Seguridad', severidad: 'high', estado: 'en-atencion', ubicacion: 'Panamericana Norte km 1024', lat: -4.4, lng: -80.2, descripcion: 'Vehículos sospechosos siguieron a la unidad por 15 km. Conductora activó botón de pánico.', creado: '2026-05-06T07:18:00', actualizado: '2026-05-06T09:42:00', asignadoA: 'Seguridad Patrimonial + PNP', foto: true, audio: true },
  { id: 'INC-2026-0139', titulo: 'Llanta delantera reventada', placa: 'AQP-334', conductor: 'Rosa Huamán', categoria: 'Mecánico', severidad: 'medium', estado: 'resuelto', ubicacion: 'Carretera Costanera, Tacna', lat: -17.0, lng: -70.85, descripcion: 'Llanta reventada por clavo. Cambio realizado por equipo de emergencia.', creado: '2026-05-05T14:20:00', actualizado: '2026-05-05T17:05:00', asignadoA: 'Asistencia en Ruta Sur', foto: true, audio: false },
  { id: 'INC-2026-0138', titulo: 'Retraso por bloqueo de vía', placa: 'CUS-558', conductor: 'Pedro Ñaupa', categoria: 'Tráfico', severidad: 'low', estado: 'resuelto', ubicacion: 'Vía Cusco - Puno km 134', lat: -14.5, lng: -71.2, descripcion: 'Bloqueo por manifestación local. Vía liberada después de 2 horas.', creado: '2026-05-04T11:00:00', actualizado: '2026-05-04T13:20:00', asignadoA: 'Operaciones', foto: false, audio: false },
  { id: 'INC-2026-0137', titulo: 'Sobrecarga detectada', placa: 'JUL-477', conductor: 'Elena Choque', categoria: 'Operativo', severidad: 'medium', estado: 'asignado', ubicacion: 'Pesaje Juliaca', lat: -15.5, lng: -70.13, descripcion: 'Sensor de peso reporta 3% sobre límite legal. Requiere redistribución.', creado: '2026-05-06T06:50:00', actualizado: '2026-05-06T07:15:00', asignadoA: 'Logística', foto: false, audio: false },
  { id: 'INC-2026-0136', titulo: 'Accidente leve sin lesionados', placa: 'TRJ-013', conductor: 'Hugo Mamani', categoria: 'Accidente', severidad: 'high', estado: 'reportado', ubicacion: 'Panamericana Norte km 487', lat: -9.5, lng: -77.5, descripcion: 'Colisión leve por alcance. Sin lesionados. Pendiente atestado policial.', creado: '2026-05-06T11:42:00', actualizado: '2026-05-06T11:42:00', asignadoA: null, foto: true, audio: false },
  { id: 'INC-2026-0135', titulo: 'Temperatura de motor elevada', placa: 'ABC-123', conductor: 'Carlos Mendoza', categoria: 'Mecánico', severidad: 'low', estado: 'en-atencion', ubicacion: 'Lima Norte', lat: -12.0, lng: -77.05, descripcion: 'Sensor de temperatura por encima del rango óptimo. Monitoreo en curso.', creado: '2026-05-06T09:30:00', actualizado: '2026-05-06T10:55:00', asignadoA: 'Telemetría', foto: false, audio: false },
  { id: 'INC-2026-0134', titulo: 'Combustible bajo nivel mínimo', placa: 'ICA-960', conductor: 'Diana Castillo', categoria: 'Operativo', severidad: 'medium', estado: 'resuelto', ubicacion: 'Ica - Nazca', lat: -14.83, lng: -74.93, descripcion: 'Reabastecimiento programado en grifo Petroperú km 442.', creado: '2026-05-05T16:40:00', actualizado: '2026-05-05T18:00:00', asignadoA: 'Coordinador Sur', foto: false, audio: false },
  { id: 'INC-2026-0133', titulo: 'Conducción agresiva', placa: 'LMA-202', conductor: 'Jorge Salazar', categoria: 'Conducta', severidad: 'low', estado: 'resuelto', ubicacion: 'Panamericana Sur km 230', lat: -13.7, lng: -76.21, descripcion: 'Telemetría detecta exceso de velocidad sostenido por 12 minutos.', creado: '2026-05-04T15:10:00', actualizado: '2026-05-05T09:00:00', asignadoA: 'RRHH', foto: false, audio: false },
  { id: 'INC-2026-0132', titulo: 'Daño en carga refrigerada', placa: 'TGS-901', conductor: 'Ana Flores', categoria: 'Carga', severidad: 'high', estado: 'asignado', ubicacion: 'Trujillo Centro', lat: -8.115, lng: -79.029, descripcion: 'Falla en sistema de refrigeración. Carga de productos perecibles en riesgo.', creado: '2026-05-06T05:22:00', actualizado: '2026-05-06T06:00:00', asignadoA: 'Operaciones Norte', foto: true, audio: false },
  { id: 'INC-2026-0131', titulo: 'Documentos vencidos', placa: 'CHI-742', conductor: 'Manuel Torres', categoria: 'Administrativo', severidad: 'low', estado: 'reportado', ubicacion: 'Chiclayo', lat: -6.77, lng: -78.95, descripcion: 'SOAT vence en 3 días. Renovación pendiente.', creado: '2026-05-06T09:00:00', actualizado: '2026-05-06T09:00:00', asignadoA: null, foto: false, audio: false },
  { id: 'INC-2026-0130', titulo: 'Neblina extrema reportada', placa: 'CUS-558', conductor: 'Pedro Ñaupa', categoria: 'Tráfico', severidad: 'medium', estado: 'resuelto', ubicacion: 'Abra La Raya', lat: -14.5, lng: -71.0, descripcion: 'Visibilidad reducida a 30m. Detención precautoria por 1 hora.', creado: '2026-05-03T05:45:00', actualizado: '2026-05-03T07:10:00', asignadoA: 'Operaciones', foto: false, audio: false },
  { id: 'INC-2026-0129', titulo: 'Batería descargada', placa: 'DGR-456', conductor: 'María Quispe', categoria: 'Mecánico', severidad: 'medium', estado: 'resuelto', ubicacion: 'Salida Arequipa', lat: -16.4, lng: -71.5, descripcion: 'Auxilio eléctrico despachado. Reemplazo de batería completado.', creado: '2026-05-02T08:00:00', actualizado: '2026-05-02T11:30:00', asignadoA: 'Asistencia en Ruta Sur', foto: true, audio: false },
  { id: 'INC-2026-0128', titulo: 'Robo de mercancía menor', placa: 'PER-789', conductor: 'Luis Vargas', categoria: 'Seguridad', severidad: 'high', estado: 'resuelto', ubicacion: 'Estación de servicio Huancayo', lat: -12.07, lng: -75.21, descripcion: 'Sustracción de 4 cajas durante parada. Denuncia presentada.', creado: '2026-05-01T22:15:00', actualizado: '2026-05-02T14:00:00', asignadoA: 'Seguridad Patrimonial', foto: true, audio: false }
];

export const SEED_AI_ALERTS: AiAlert[] = [
  { id: 'ai-1', titulo: 'Retraso detectado en Carretera Central', descripcion: 'Patrón de tráfico sugiere retrasos de 35-50 min en las próximas 2h. 3 unidades afectadas.', severidad: 'high', icon: 'alert-triangle', tiempo: 'hace 6 min', afecta: ['PER-789', 'ABC-123', 'TRJ-013'] },
  { id: 'ai-2', titulo: 'Riesgo de mantenimiento — DGR-456', descripcion: 'Modelo predictivo: 78% probabilidad de falla en transmisión en próximos 5 días.', severidad: 'medium', icon: 'wrench', tiempo: 'hace 22 min', afecta: ['DGR-456'] },
  { id: 'ai-3', titulo: 'Zona de alto riesgo — Panamericana Norte', descripcion: 'Aumento del 40% en incidentes de seguridad en km 980-1050 últimas 72h.', severidad: 'high', icon: 'shield-alert', tiempo: 'hace 1 h', afecta: ['PIU-101'] },
  { id: 'ai-4', titulo: 'Optimización de ruta — Lima → Pisco', descripcion: 'Ruta alternativa por Cañete reduce tiempo estimado en 28 min.', severidad: 'low', icon: 'route', tiempo: 'hace 2 h', afecta: ['LMA-202'] },
  { id: 'ai-5', titulo: 'Fatiga de conductor detectada', descripcion: 'Patrón de conducción de Hugo Mamani sugiere fatiga. Recomendar descanso.', severidad: 'medium', icon: 'moon', tiempo: 'hace 3 h', afecta: ['TRJ-013'] }
];

export const SEED_KPIS: Kpi[] = [
  { label: 'Vehículos activos', value: '10 / 12', trend: '+2', icon: 'truck', color: 'blue' },
  { label: 'Incidencias hoy', value: '7', trend: '-12%', icon: 'alert-triangle', color: 'red' },
  { label: 'Tiempo promedio respuesta', value: '18 min', trend: '-3 min', icon: 'clock', color: 'green' },
  { label: 'Alertas IA pendientes', value: '5', trend: '+1', icon: 'sparkles', color: 'violet' }
];

export const SEED_ACTIVITY: ActivityItem[] = [
  { dot: 'emerald', html: '<strong class="text-slate-900">ABC-123</strong> inició ruta Lima → Trujillo a las 06:42' },
  { dot: 'red', html: '<strong class="text-slate-900">PER-789</strong> reportó falla de frenos · Carretera Central' },
  { dot: 'amber', html: '<strong class="text-slate-900">DGR-456</strong> detenido en salida sur de Arequipa' },
  { dot: 'emerald', html: 'Incidencia <strong class="text-slate-900">INC-0139</strong> resuelta — llanta cambiada' }
];

export const SEED_ROUTES: RouteProgress[] = [
  { ruta: 'Lima → Trujillo', pct: 68, color: 'emerald' },
  { ruta: 'Arequipa → Cusco', pct: 42, color: 'amber' },
  { ruta: 'Trujillo → Chiclayo', pct: 85, color: 'emerald' },
  { ruta: 'Lima → Pisco', pct: 94, color: 'emerald' }
];

export const SEED_HEATMAP: HeatmapPoint[] = [
  [-12.0464, -77.0428, 0.9], [-12.06, -77.05, 0.85], [-12.04, -77.03, 0.8], [-12.07, -77.07, 0.75], [-12.02, -76.99, 0.7], [-12.09, -77.02, 0.65], [-11.99, -77.06, 0.6], [-12.05, -77.0, 0.55], [-12.03, -77.04, 0.5], [-12.08, -76.95, 0.45],
  [-11.94, -76.23, 0.85], [-11.96, -76.4, 0.7], [-11.92, -76.1, 0.6],
  [-16.409, -71.537, 0.7], [-16.42, -71.52, 0.6], [-16.4, -71.55, 0.5],
  [-8.115, -79.029, 0.65], [-8.12, -79.03, 0.55], [-8.1, -79.02, 0.45],
  [-6.77, -79.84, 0.6], [-6.78, -79.85, 0.5],
  [-5.19, -80.63, 0.55], [-5.18, -80.62, 0.45],
  [-13.53, -71.96, 0.55], [-13.52, -71.95, 0.45],
  [-18.01, -70.25, 0.4], [-18.0, -70.24, 0.35],
  [-3.74, -73.25, 0.45], [-8.39, -74.55, 0.4],
  [-12.07, -75.21, 0.6], [-12.08, -75.2, 0.5],
  [-14.06, -75.73, 0.5], [-14.05, -75.74, 0.4],
  [-3.57, -80.46, 0.5], [-7.16, -78.51, 0.45],
  [-9.07, -78.59, 0.55], [-15.84, -70.02, 0.4],
  [-6.49, -76.36, 0.35], [-9.53, -77.53, 0.45],
  [-13.7, -76.21, 0.5], [-17.99, -70.24, 0.35],
  [-15.5, -70.13, 0.45], [-17.19, -70.93, 0.3],
  [-13.16, -74.22, 0.4], [-9.93, -76.24, 0.35],
  [-4.9, -80.69, 0.4]
];

export const SEED_CHART_BARS: ChartBars = {
  labels: ['Nov', 'Dic', 'Ene', 'Feb', 'Mar', 'Abr', 'May'],
  datasets: [
    { label: 'Mecánico', data: [12, 15, 18, 14, 11, 16, 9] },
    { label: 'Tráfico', data: [8, 11, 14, 9, 12, 10, 7] },
    { label: 'Seguridad', data: [4, 6, 5, 7, 8, 11, 6] },
    { label: 'Accidente', data: [3, 2, 4, 3, 5, 4, 2] }
  ]
};

export const SEED_CHART_DONUT: ChartDonut = {
  labels: ['Mecánico', 'Tráfico', 'Seguridad', 'Accidente', 'Operativo'],
  data: [38, 27, 18, 9, 8]
};

export const SEED_CHART_TREND: ChartTrend = {
  labels: ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4', 'Sem 5', 'Sem 6', 'Sem 7', 'Sem 8'],
  data: [22, 26, 19, 24, 18, 15, 21, 17]
};

export const SAMPLE_ROUTES = [
  { color: '#10b981', coords: [[-12.0464, -77.0428], [-9.5, -77.5], [-8.115, -79.029]] as [number, number][] },
  { color: '#3b82f6', coords: [[-16.409, -71.537], [-15.5, -70.13], [-13.53, -71.96]] as [number, number][] },
  { color: '#f59e0b', coords: [[-12.0464, -77.0428], [-11.94, -76.23], [-12.07, -75.21]] as [number, number][] }
];
