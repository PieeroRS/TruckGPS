import { CommonModule } from '@angular/common';
import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ArrowRight, Download, LucideAngularModule, Plus, Search, Truck } from 'lucide-angular';
import { Vehicle, VehicleStatus } from '../../core/models/vehicle.model';
import { FleetService } from '../../core/services/fleet.service';
import { LayoutService } from '../../core/services/layout.service';
import { formatDate, formatKm, vehicleStatusInfo } from '../../core/utils/map.utils';

@Component({
  standalone: true,
  selector: 'app-flota-page',
  imports: [CommonModule, FormsModule, LucideAngularModule],
  template: `
    <div class="p-4 sm:p-6 lg:p-8">
      <div class="flex items-end justify-between flex-wrap gap-3 mb-6">
        <div>
          <h2 class="text-lg sm:text-xl font-bold text-slate-900">Flota completa</h2>
          <p class="text-xs text-slate-500 mt-1">Estado, ubicación y mantenimiento de todos los vehículos.</p>
        </div>
        <div class="flex items-center gap-2">
          <button type="button" class="inline-flex items-center gap-1.5 px-3 py-2 rounded-md border border-slate-200 bg-white text-slate-700 text-xs font-semibold hover:bg-slate-50 transition">
            <lucide-icon [img]="downloadIcon" [size]="14" />Exportar
          </button>
          <button type="button" class="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-slate-900 text-white text-xs font-semibold hover:bg-slate-800 transition">
            <lucide-icon [img]="plusIcon" [size]="14" />Agregar vehículo
          </button>
        </div>
      </div>

      <div class="card p-4 mb-5">
        <div class="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div class="md:col-span-7">
            <label class="input-label">Buscar</label>
            <div class="relative">
              <lucide-icon [img]="searchIcon" [size]="14" class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input type="text" class="input pl-9" placeholder="Placa, conductor, modelo o ruta..." [(ngModel)]="busqueda" (ngModelChange)="refresh()" />
            </div>
          </div>
          <div class="md:col-span-5">
            <label class="input-label">Estado</label>
            <select class="select" [(ngModel)]="estado" (ngModelChange)="refresh()">
              <option value="todos">Todos</option>
              <option value="ok">En ruta</option>
              <option value="warn">Detenido</option>
              <option value="alert">Alerta</option>
              <option value="offline">Offline</option>
            </select>
          </div>
        </div>
      </div>

      <p class="text-xs text-slate-500 mb-3">{{ filtered().length }} de {{ fleet.count() }}</p>

      <div class="card overflow-hidden">
        <div class="overflow-x-auto">
          <table class="w-full text-left">
            <thead class="bg-slate-50 border-b border-slate-200 text-[11px] uppercase tracking-wider text-slate-500">
              <tr>
                <th class="px-4 py-3 font-semibold">Vehículo</th>
                <th class="px-4 py-3 font-semibold">Conductor</th>
                <th class="px-4 py-3 font-semibold">Estado</th>
                <th class="px-4 py-3 font-semibold">Ruta</th>
                <th class="px-4 py-3 font-semibold">Velocidad</th>
                <th class="px-4 py-3 font-semibold">Kilometraje</th>
                <th class="px-4 py-3 font-semibold">Próx. mant.</th>
                <th class="px-4 py-3 font-semibold text-right">Acción</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 text-sm">
              @if (filtered().length === 0) {
                <tr><td colspan="8" class="px-6 py-10 text-center text-sm text-slate-500">Sin resultados.</td></tr>
              }
              @for (v of filtered(); track v.placa) {
                <tr class="hover:bg-slate-50 transition">
                  <td class="px-4 py-3.5">
                    <div class="flex items-center gap-3">
                      <div class="w-9 h-9 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600 shrink-0">
                        <lucide-icon [img]="truckIcon" [size]="16" />
                      </div>
                      <div>
                        <div class="text-sm font-semibold text-slate-900 font-mono">{{ v.placa }}</div>
                        <div class="text-[11px] text-slate-500">{{ v.modelo }}</div>
                      </div>
                    </div>
                  </td>
                  <td class="px-4 py-3.5 text-slate-700">{{ v.conductor }}</td>
                  <td class="px-4 py-3.5"><span class="badge" [class]="statusInfo(v.estado).badge">{{ statusInfo(v.estado).label }}</span></td>
                  <td class="px-4 py-3.5 text-slate-600">{{ v.ruta }}</td>
                  <td class="px-4 py-3.5 font-semibold" [class]="v.velocidad > 0 ? 'text-emerald-600' : 'text-slate-400'">{{ v.velocidad }} km/h</td>
                  <td class="px-4 py-3.5 text-slate-700 font-mono">{{ fmtKm(v.km) }}</td>
                  <td class="px-4 py-3.5">
                    <div class="flex items-center gap-2">
                      <span class="text-xs" [class]="mantSoon(v) ? 'text-red-600 font-semibold' : 'text-slate-600'">{{ fmtDate(v.proxMant) }}</span>
                      @if (mantDays(v) <= 7) { <span class="badge badge-danger">{{ mantDays(v) }}d</span> }
                    </div>
                  </td>
                  <td class="px-4 py-3.5 text-right">
                    <button type="button" class="text-blue-700 hover:text-blue-900 text-xs font-semibold flex items-center gap-1 ml-auto">
                      Ver detalle <lucide-icon [img]="arrowIcon" [size]="12" />
                    </button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class FlotaPageComponent implements OnInit {
  readonly fleet = inject(FleetService);
  private readonly layout = inject(LayoutService);

  readonly downloadIcon = Download;
  readonly plusIcon = Plus;
  readonly searchIcon = Search;
  readonly truckIcon = Truck;
  readonly arrowIcon = ArrowRight;
  readonly statusInfo = vehicleStatusInfo;
  readonly fmtKm = formatKm;
  readonly fmtDate = formatDate;

  estado: VehicleStatus | 'todos' = 'todos';
  busqueda = '';
  readonly filteredList = signal<Vehicle[]>([]);

  ngOnInit(): void {
    this.layout.setPage('Flota', 'Estado y mantenimiento de todos los vehículos');
    void this.fleet.load().then(() => this.refresh());
  }

  filtered(): Vehicle[] {
    return this.filteredList();
  }

  mantDays(v: Vehicle): number {
    return Math.ceil((new Date(v.proxMant).getTime() - Date.now()) / (1000 * 60 * 60 * 24));
  }

  mantSoon(v: Vehicle): boolean {
    return this.mantDays(v) <= 7;
  }

  refresh(): void {
    this.filteredList.set(this.fleet.filter(this.estado, this.busqueda));
  }
}
